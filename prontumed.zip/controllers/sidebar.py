# -*- coding: utf-8 -*-
def index():
    return dict()
