# -*- coding: utf-8 -*-
{
'actualizada': ['actualizadas'],
'eliminada': ['eliminadas'],
'fila': ['filas'],
'seleccionado': ['seleccionados'],
}
